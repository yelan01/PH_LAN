﻿namespace pH_Link_Wireless
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label001 = new System.Windows.Forms.Label();
            this.label002 = new System.Windows.Forms.Label();
            this.label003 = new System.Windows.Forms.Label();
            this.label004 = new System.Windows.Forms.Label();
            this.label005 = new System.Windows.Forms.Label();
            this.label010 = new System.Windows.Forms.Label();
            this.label009 = new System.Windows.Forms.Label();
            this.label008 = new System.Windows.Forms.Label();
            this.label007 = new System.Windows.Forms.Label();
            this.label006 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.AVERIGE = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.comboBoxPort = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("PMingLiU", 60F);
            this.label1.Location = new System.Drawing.Point(48, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(194, 80);
            this.label1.TabIndex = 0;
            this.label1.Text = "高科";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("PMingLiU", 30F);
            this.label2.Location = new System.Drawing.Point(48, 157);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 40);
            this.label2.TabIndex = 1;
            this.label2.Text = "PH";
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("PMingLiU", 30F);
            this.textBox2.Location = new System.Drawing.Point(798, 157);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(414, 55);
            this.textBox2.TabIndex = 3;
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // label001
            // 
            this.label001.AutoSize = true;
            this.label001.Font = new System.Drawing.Font("PMingLiU", 60F);
            this.label001.Location = new System.Drawing.Point(49, 286);
            this.label001.Name = "label001";
            this.label001.Size = new System.Drawing.Size(110, 80);
            this.label001.TabIndex = 4;
            this.label001.Text = "01";
            this.label001.Click += new System.EventHandler(this.label001_Click);
            // 
            // label002
            // 
            this.label002.AutoSize = true;
            this.label002.Font = new System.Drawing.Font("PMingLiU", 60F);
            this.label002.Location = new System.Drawing.Point(249, 286);
            this.label002.Name = "label002";
            this.label002.Size = new System.Drawing.Size(110, 80);
            this.label002.TabIndex = 5;
            this.label002.Text = "02";
            // 
            // label003
            // 
            this.label003.AutoSize = true;
            this.label003.Font = new System.Drawing.Font("PMingLiU", 60F);
            this.label003.Location = new System.Drawing.Point(449, 286);
            this.label003.Name = "label003";
            this.label003.Size = new System.Drawing.Size(110, 80);
            this.label003.TabIndex = 6;
            this.label003.Text = "03";
            // 
            // label004
            // 
            this.label004.AutoSize = true;
            this.label004.Font = new System.Drawing.Font("PMingLiU", 60F);
            this.label004.Location = new System.Drawing.Point(649, 286);
            this.label004.Name = "label004";
            this.label004.Size = new System.Drawing.Size(110, 80);
            this.label004.TabIndex = 7;
            this.label004.Text = "04";
            // 
            // label005
            // 
            this.label005.AutoSize = true;
            this.label005.Font = new System.Drawing.Font("PMingLiU", 60F);
            this.label005.Location = new System.Drawing.Point(849, 286);
            this.label005.Name = "label005";
            this.label005.Size = new System.Drawing.Size(110, 80);
            this.label005.TabIndex = 8;
            this.label005.Text = "05";
            // 
            // label010
            // 
            this.label010.AutoSize = true;
            this.label010.Font = new System.Drawing.Font("PMingLiU", 60F);
            this.label010.Location = new System.Drawing.Point(849, 366);
            this.label010.Name = "label010";
            this.label010.Size = new System.Drawing.Size(110, 80);
            this.label010.TabIndex = 13;
            this.label010.Text = "10";
            // 
            // label009
            // 
            this.label009.AutoSize = true;
            this.label009.Font = new System.Drawing.Font("PMingLiU", 60F);
            this.label009.Location = new System.Drawing.Point(649, 366);
            this.label009.Name = "label009";
            this.label009.Size = new System.Drawing.Size(110, 80);
            this.label009.TabIndex = 12;
            this.label009.Text = "09";
            // 
            // label008
            // 
            this.label008.AutoSize = true;
            this.label008.Font = new System.Drawing.Font("PMingLiU", 60F);
            this.label008.Location = new System.Drawing.Point(449, 366);
            this.label008.Name = "label008";
            this.label008.Size = new System.Drawing.Size(110, 80);
            this.label008.TabIndex = 11;
            this.label008.Text = "08";
            // 
            // label007
            // 
            this.label007.AutoSize = true;
            this.label007.Font = new System.Drawing.Font("PMingLiU", 60F);
            this.label007.Location = new System.Drawing.Point(249, 366);
            this.label007.Name = "label007";
            this.label007.Size = new System.Drawing.Size(110, 80);
            this.label007.TabIndex = 10;
            this.label007.Text = "07";
            // 
            // label006
            // 
            this.label006.AutoSize = true;
            this.label006.Font = new System.Drawing.Font("PMingLiU", 60F);
            this.label006.Location = new System.Drawing.Point(49, 366);
            this.label006.Name = "label006";
            this.label006.Size = new System.Drawing.Size(110, 80);
            this.label006.TabIndex = 9;
            this.label006.Text = "06";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("PMingLiU", 60F);
            this.button1.Location = new System.Drawing.Point(170, 477);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(683, 154);
            this.button1.TabIndex = 14;
            this.button1.Text = "連線";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // AVERIGE
            // 
            this.AVERIGE.AutoSize = true;
            this.AVERIGE.Font = new System.Drawing.Font("PMingLiU", 100F);
            this.AVERIGE.Location = new System.Drawing.Point(1069, 286);
            this.AVERIGE.Name = "AVERIGE";
            this.AVERIGE.Size = new System.Drawing.Size(325, 134);
            this.AVERIGE.TabIndex = 15;
            this.AVERIGE.Text = "平均";
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("PMingLiU", 30F);
            this.textBox3.Location = new System.Drawing.Point(119, 154);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(385, 55);
            this.textBox3.TabIndex = 16;
            this.textBox3.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("PMingLiU", 80F);
            this.label14.Location = new System.Drawing.Point(921, 492);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(473, 107);
            this.label14.TabIndex = 17;
            this.label14.Text = "連線成功";
            this.label14.Click += new System.EventHandler(this.label14_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("PMingLiU", 30F);
            this.label3.Location = new System.Drawing.Point(539, 44);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(242, 40);
            this.label3.TabIndex = 18;
            this.label3.Text = "PORT_NAME";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("PMingLiU", 30F);
            this.label4.Location = new System.Drawing.Point(564, 160);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(217, 40);
            this.label4.TabIndex = 19;
            this.label4.Text = "幾秒計一次";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // comboBoxPort
            // 
            this.comboBoxPort.Font = new System.Drawing.Font("PMingLiU", 30F);
            this.comboBoxPort.FormattingEnabled = true;
            this.comboBoxPort.Location = new System.Drawing.Point(798, 41);
            this.comboBoxPort.Name = "comboBoxPort";
            this.comboBoxPort.Size = new System.Drawing.Size(401, 48);
            this.comboBoxPort.TabIndex = 20;
            this.comboBoxPort.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1427, 793);
            this.Controls.Add(this.comboBoxPort);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.AVERIGE);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label010);
            this.Controls.Add(this.label009);
            this.Controls.Add(this.label008);
            this.Controls.Add(this.label007);
            this.Controls.Add(this.label006);
            this.Controls.Add(this.label005);
            this.Controls.Add(this.label004);
            this.Controls.Add(this.label003);
            this.Controls.Add(this.label002);
            this.Controls.Add(this.label001);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label001;
        private System.Windows.Forms.Label label002;
        private System.Windows.Forms.Label label003;
        private System.Windows.Forms.Label label004;
        private System.Windows.Forms.Label label005;
        private System.Windows.Forms.Label label010;
        private System.Windows.Forms.Label label009;
        private System.Windows.Forms.Label label008;
        private System.Windows.Forms.Label label007;
        private System.Windows.Forms.Label label006;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label AVERIGE;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Timer timer1;
        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.ComboBox comboBoxPort;
    }
}

