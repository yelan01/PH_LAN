﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace pH_Link_Wireless
{
    public partial class Form1 : Form
    {
        // ===== 序列埠物件 =====
        private SerialPort serialPort;

        // ===== 接收資料緩衝 =====
        private readonly StringBuilder receiveBuffer = new StringBuilder();
        private readonly object bufferLock = new object();

        // ===== 儲存數值用 Queue（固定只顯示 10 筆）=====
        private readonly Queue<float> floatQueue = new Queue<float>();
        private const int QueueMaxItems = 10;

        // ===== 採樣控制 =====
        private int sampleInterval = 1; // 每收到 interval 次完整行才存一次
        private int sampleCounter = 0;

        // ✅ 已成功「存進 queue」的筆數
        private int storedCount = 0;

        public Form1()
        {
            InitializeComponent();

            this.FormClosing += Form1_FormClosing;

            // 下拉選單展開時重掃 COM
            this.comboBoxPort.DropDown += (s, e) => RefreshSerialPortList();

            // 確保按鈕事件有綁定
            this.button1.Click += button1_Click;

            // 採樣間隔即時更新
            this.textBox2.TextChanged += textBox2_TextChanged;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            RefreshSerialPortList();

            // 初始化連線狀態顯示
            if (label14 != null)
            {
                label14.Text = "未連線";
                label14.ForeColor = Color.Red;
            }

            // 初始化 sampleInterval
            sampleInterval = GetIntervalFromTextBox();
            sampleCounter = 0;

            // 初始化顯示
            UpdateLabelsFromQueue();
        }

        // ===== 掃描可用 COM 埠 =====
        private void RefreshSerialPortList()
        {
            comboBoxPort.Items.Clear();

            string[] ports = SerialPort.GetPortNames();
            comboBoxPort.Items.AddRange(ports);

            if (comboBoxPort.Items.Count > 0)
                comboBoxPort.SelectedIndex = 0;
        }

        // ===== 連線 / 中斷按鈕 =====
        private void button1_Click(object sender, EventArgs e)
        {
            // 已連線就中斷（使用者手動）
            if (serialPort != null && serialPort.IsOpen)
            {
                DisconnectSerialPort(false);
                return;
            }

            // 取得 COM 名稱
            string portName = null;
            if (comboBoxPort.SelectedItem != null)
                portName = comboBoxPort.SelectedItem.ToString();
            else
                portName = comboBoxPort.Text;

            if (string.IsNullOrWhiteSpace(portName))
            {
                MessageBox.Show(this, "請先選擇或輸入 COM 埠名稱。",
                    "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                serialPort = new SerialPort(portName, 9600, Parity.None, 8, StopBits.One)
                {
                    ReadTimeout = 500,
                    WriteTimeout = 500,
                    Encoding = Encoding.UTF8
                };

                serialPort.DataReceived += SerialPort_DataReceived;
                serialPort.Open();

                // UI 更新
                button1.Text = "中斷";
                comboBoxPort.Enabled = false;
                this.Text = $"Form1 - {portName} 已連線";

                if (label14 != null)
                {
                    label14.Text = "連線成功";
                    label14.ForeColor = Color.Green;
                }

                // 清空顯示與資料
                textBox3.Clear();
                lock (bufferLock)
                {
                    receiveBuffer.Clear();
                    floatQueue.Clear();
                }

                // 重置採樣與計數
                sampleInterval = GetIntervalFromTextBox();
                sampleCounter = 0;
                storedCount = 0;

                UpdateLabelsFromQueue();
            }
            catch (Exception ex)
            {
                try
                {
                    if (serialPort != null)
                    {
                        serialPort.DataReceived -= SerialPort_DataReceived;
                        serialPort.Dispose();
                    }
                }
                catch { }

                serialPort = null;

                if (label14 != null)
                {
                    label14.Text = "連線失敗";
                    label14.ForeColor = Color.Red;
                }

                MessageBox.Show(this, $"無法開啟序列埠 {portName}：{ex.Message}",
                    "序列埠錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);

                this.Text = "Form1";
            }
        }

        // ✅ 中斷序列埠（reachedLimit=true 代表收滿 10 筆自動斷線）
        private void DisconnectSerialPort(bool reachedLimit)
        {
            if (serialPort == null) return;

            try
            {
                serialPort.DataReceived -= SerialPort_DataReceived;
                if (serialPort.IsOpen) serialPort.Close();
            }
            catch
            {
            }
            finally
            {
                try { serialPort.Dispose(); } catch { }
                serialPort = null;

                button1.Text = "連線";
                comboBoxPort.Enabled = true;
                this.Text = "Form1";

                // 清空緩衝與 queue
                lock (bufferLock)
                {
                    receiveBuffer.Clear();
                    floatQueue.Clear();
                }

                sampleCounter = 0;
                storedCount = 0;

                UpdateLabelsFromQueue();

                if (label14 != null)
                {
                    if (reachedLimit)
                    {
                        label14.Text = "已收滿 10 筆並斷線";
                        label14.ForeColor = Color.Blue;
                    }
                    else
                    {
                        label14.Text = "已中斷";
                        label14.ForeColor = Color.Red;
                    }
                }
            }
        }

        // ===== 收到序列資料事件 =====
        private void SerialPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            try
            {
                var sp = sender as SerialPort;
                string chunk = sp?.ReadExisting();
                if (string.IsNullOrEmpty(chunk)) return;

                string lastCompleteLine = null;

                lock (bufferLock)
                {
                    receiveBuffer.Append(chunk);

                    while (true)
                    {
                        string buf = receiveBuffer.ToString();
                        int newlinePos = buf.IndexOf('\n');
                        if (newlinePos < 0) break;

                        string line = buf.Substring(0, newlinePos + 1);
                        line = line.TrimEnd('\r', '\n');

                        lastCompleteLine = line;
                        receiveBuffer.Remove(0, newlinePos + 1);
                    }

                    const int maxBuffer = 4096;
                    if (receiveBuffer.Length > maxBuffer)
                        receiveBuffer.Remove(0, receiveBuffer.Length - maxBuffer);
                }

                if (lastCompleteLine == null) return;

                // ✅ 如果已經收滿 10 筆（保險）
                if (storedCount >= 10) return;

                // ===== 採樣計數 =====
                bool shouldEnqueue = false;
                lock (bufferLock)
                {
                    sampleCounter++;
                    if (sampleCounter >= sampleInterval)
                    {
                        shouldEnqueue = true;
                        sampleCounter = 0;
                    }
                }

                // ===== 不到採樣點，只更新 textBox3 =====
                if (!shouldEnqueue)
                {
                    this.BeginInvoke(new Action(() =>
                    {
                        textBox3.Text = lastCompleteLine.Trim();
                    }));
                    return;
                }

                // ===== 到採樣點：嘗試解析並加入 queue =====
                bool added = AddFirstFloatFromLineToQueue(lastCompleteLine);
                if (!added)
                {
                    // 解析不到數字也顯示最近一筆
                    this.BeginInvoke(new Action(() =>
                    {
                        textBox3.Text = lastCompleteLine.Trim();
                    }));
                    return;
                }

                storedCount++;

                // ===== UI 更新 =====
                this.BeginInvoke(new Action(() =>
                {
                    textBox3.Text = lastCompleteLine.Trim();
                    UpdateLabelsFromQueue();

                    // ✅ 收滿 10 筆就自動斷線
                    if (storedCount >= 10)
                    {
                        DisconnectSerialPort(true);
                    }
                }));
            }
            catch
            {
            }
        }

        // ✅ 改成回傳 bool：有成功加入就 true
        private bool AddFirstFloatFromLineToQueue(string line)
        {
            if (string.IsNullOrWhiteSpace(line)) return false;

            var m = Regex.Match(line, @"-?\d+(\.\d+)?");
            if (!m.Success) return false;

            if (!float.TryParse(m.Value, NumberStyles.Float, CultureInfo.InvariantCulture, out float v))
            {
                if (!float.TryParse(m.Value, out v)) return false;
            }

            lock (bufferLock)
            {
                floatQueue.Enqueue(v);

                // 這裡雖然仍有保護，但實際上你會在滿 10 後斷線
                while (floatQueue.Count > QueueMaxItems)
                    floatQueue.Dequeue();
            }

            return true;
        }

        // ===== 讀取採樣間隔 =====
        private int GetIntervalFromTextBox()
        {
            if (textBox2 == null) return 1;
            if (int.TryParse(textBox2.Text, out int n) && n > 0) return n;
            return 1;
        }

        // ===== 更新 label001~010 與平均值 =====
        private void UpdateLabelsFromQueue()
        {
            float[] snapshot;
            lock (bufferLock)
            {
                snapshot = floatQueue.ToArray();
            }

            if (this.InvokeRequired)
            {
                this.BeginInvoke(new Action(UpdateLabelsFromQueue));
                return;
            }

            label001.Text = "";
            label002.Text = "";
            label003.Text = "";
            label004.Text = "";
            label005.Text = "";
            label006.Text = "";
            label007.Text = "";
            label008.Text = "";
            label009.Text = "";
            label010.Text = "";

            for (int i = 0; i < snapshot.Length && i < QueueMaxItems; i++)
            {
                string s = snapshot[i].ToString(CultureInfo.InvariantCulture);
                switch (i)
                {
                    case 0: label001.Text = s; break;
                    case 1: label002.Text = s; break;
                    case 2: label003.Text = s; break;
                    case 3: label004.Text = s; break;
                    case 4: label005.Text = s; break;
                    case 5: label006.Text = s; break;
                    case 6: label007.Text = s; break;
                    case 7: label008.Text = s; break;
                    case 8: label009.Text = s; break;
                    case 9: label010.Text = s; break;
                }
            }

            UpdateAverageLabel(snapshot);
        }

        private void UpdateAverageLabel(float[] snapshot)
        {
            if (this.InvokeRequired)
            {
                this.BeginInvoke(new Action<float[]>(UpdateAverageLabel), snapshot);
                return;
            }

            if (snapshot == null || snapshot.Length == 0)
            {
                AVERIGE.Text = "0";
                return;
            }

            double avg = snapshot.Average(x => (double)x);
            AVERIGE.Text = avg.ToString("0.##", CultureInfo.InvariantCulture);
        }

        // ===== 採樣間隔變更 =====
        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            int newInterval = GetIntervalFromTextBox();
            lock (bufferLock)
            {
                sampleInterval = newInterval;
            }
        }

        // ===== 取得 queue 快照 =====
        public float[] GetFloatQueueSnapshot()
        {
            lock (bufferLock)
            {
                return floatQueue.ToArray();
            }
        }

        // ===== 關窗時確保斷線 =====
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (serialPort != null)
            {
                try
                {
                    serialPort.DataReceived -= SerialPort_DataReceived;
                    if (serialPort.IsOpen) serialPort.Close();
                }
                catch { }
                finally
                {
                    try { serialPort.Dispose(); } catch { }
                    serialPort = null;
                }
            }
        }

        // Designer 可能需要的空事件（可留可刪）
        private void textBox3_TextChanged(object sender, EventArgs e) { }
        private void label4_Click(object sender, EventArgs e) { }
        private void label14_Click(object sender, EventArgs e) { }
        private void label001_Click(object sender, EventArgs e) { }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e) { }
    }
}
